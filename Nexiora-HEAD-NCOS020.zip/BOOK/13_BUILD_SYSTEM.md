# Build System

CMake + nxbuild.
